#******************************
#Author: Noohn Hassan and Taruja Pathmarajah
#Date: January 5, 2022
#Last Revised: January 18, 2022
#Description: CovidCraze - Pygame program that teaches the basics of COVID-19. Features include: game, quiz, result, lesson, and exit.  
#******************************


#Import & initialize the pygame module
import pygame
import random
#pygame.locals contains constants like MOUSEMOTION and MOUSEBUTTONUP and QUIT for events. #It's easier to type MOUSEBUTTONUP instead of pygame.locals.MOUSEBUTTONUP
from pygame.locals import *  
# better use pygame.MOUSEMOTION

#This will allow us to name the colours to use rather than give a name  eg (255,0,0)
from pygame.color import THECOLORS
#c=(255,0,0) instead of THECOLORS['red']????

# initial library itself
pygame.init()  

#Just like python, we will use os and time????
import os, time

#this code is necessary for python to work on tdsb computers????
import platform
if platform.system() == "Windows":
    os.environ['SDL_VIDEODRIVER'] = 'windib'

#Set-up the main screen display window and caption  in the 
size = (800,449)  
screen = pygame.display.set_mode(size) 

#Puts a caption in the bar at the top of the window
pygame.display.set_caption("Covid Craze") 

# Fills the memory screen surface with colour
screen.fill((9, 200, 0)) 

#Update and refresh the display to end this frame
pygame.display.flip() #<-- refresh the display

#The game loop
clock = pygame.time.Clock() #<-- used to control the frame rate
keepGoing = True 	    #<-- a 'flag' variable for the game loop condition
time=0
# Set up the font and the size 
bigfont = pygame.font.SysFont("comicsansms", 42)
font_score = pygame.font.SysFont("Bauhaus 93", 30)

#define colours
white = (255, 255, 255)

#sub programs

#Displays text on screen
def draw_text(text, font, text_col, x, y):
  img = font.render(text, True, text_col)
  screen.blit(img, (x, y))

#Displays an image background
def setBackground(file):
  image=pygame.image.load(file).convert()
  image=pygame.transform.scale(image, (800, 449))  
  screen.blit(image, (0,0))

#Displays the menu options, back, and next buttons  
def button(file):
  button=pygame.image.load(file).convert_alpha()
  button=pygame.transform.scale(button, (100, 40))
  return button

#Answer options for the quiz
def quizOption(file):
  option=pygame.image.load(file).convert_alpha()
  option=pygame.transform.scale(option,(129,109))
  return option
#--------game stuff----------
screen_width = 800
screen_height = 449

#game variables
tile_size = 30
game_over = 0
score = 0
next=False

#images for game
sun_img = pygame.image.load('img/sun.png')
bg_img = pygame.image.load('img/sky.png')

#functions below all by Coding With Russ on YouTube

#class player is calling the sprites 
class Player():
    def __init__(self, x, y):
         self.reset(x, y)

    #Updates whats in the prameters for the game
    def update(self, game_over):
        dx = 0
        dy = 0
        walk_cooldown = 5

        if game_over == 0:
            #get keypresses
            key = pygame.key.get_pressed()
            if key[pygame.K_SPACE] and self.jumped == False:
                self.vel_y = -15
                self.jumped = True
            if key[pygame.K_SPACE] == False:
                self.jumped = False
            if key[pygame.K_LEFT]:
                dx -= 5
                self.counter += 1
                self.direction = -1
            if key[pygame.K_RIGHT]:
                dx += 5
                self.counter += 1
                self.direction = 1
            if key[pygame.K_LEFT] == False and key[pygame.K_RIGHT] == False:
                self.counter = 0
                self.index = 0
                if self.direction == 1:
                    self.image = self.images_right[self.index]
                if self.direction == -1:
                    self.image = self.images_left[self.index]


            #handle animation
            if self.counter > walk_cooldown:
                self.counter = 0    
                self.index += 1
                if self.index >= len(self.images_right):
                    self.index = 0
                if self.direction == 1:
                    self.image = self.images_right[self.index]
                if self.direction == -1:
                    self.image = self.images_left[self.index]


            #add gravity
            self.vel_y += 1
            if self.vel_y > 10:
                self.vel_y = 10
            dy += self.vel_y

            #check for collision
            for tile in world.tile_list:
                #check for collision in x direction
                if tile[1].colliderect(self.rect.x + dx, self.rect.y, self.width, self.height):
                    dx = 0
                #check for collision in y direction
                if tile[1].colliderect(self.rect.x, self.rect.y + dy, self.width, self.height):
                    #check if below the ground i.e. jumping
                    if self.vel_y < 0:
                        dy = tile[1].bottom - self.rect.top
                        self.vel_y = 0
                    #check if above the ground i.e. falling
                    elif self.vel_y >= 0:
                        dy = tile[1].top - self.rect.bottom
                        self.vel_y = 0

            #check for collision with vaccines            
            if pygame.sprite.spritecollide(player, vaccine_group, True):
                score += 1

            #check for collision with enemies
            if pygame.sprite.spritecollide(self, virus_group, False):
                game_over = -1

            #update player coordinates
            self.rect.x += dx
            self.rect.y += dy


        elif game_over == -1:
            self.image = self.dead_image
            if self.rect.y > 200:
                self.rect.y -= 5

        #draw player onto screen
        screen.blit(self.image, self.rect)

        return game_over

    def reset(self, x, y):
        self.images_right = []
        self.images_left = []
        self.index = 0
        self.counter = 0
        for num in range(1, 5):
            img_right = pygame.image.load(f'img/guy{num}.png')
            img_right = pygame.transform.scale(img_right, (40, 80))
            img_left = pygame.transform.flip(img_right, True, False)
            self.images_right.append(img_right)
            self.images_left.append(img_left)
        self.dead_image = pygame.image.load('img/ghost.png')
        self.image = self.images_right[self.index]
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.width = self.image.get_width()
        self.height = self.image.get_height()
        self.vel_y = 0
        self.jumped = False
        self.direction = 0
        self.in_air = True

class World():
    def __init__(self, data):
        self.tile_list = []

        #load images
        dirt_img = pygame.image.load('img/dirt.png')
        grass_img = pygame.image.load('img/grass.png')

        row_count = 0
        for row in data:
            col_count = 0
            for tile in row:
                if tile == 1:
                    img = pygame.transform.scale(dirt_img, (tile_size, tile_size))
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    tile = (img, img_rect)
                    self.tile_list.append(tile)
                if tile == 2:
                    img = pygame.transform.scale(grass_img, (tile_size, tile_size))
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    tile = (img, img_rect)
                    self.tile_list.append(tile)
                if tile == 3:
                    virus = Enemy(col_count * tile_size, row_count * tile_size + 15)
                    virus_group.add(virus)
                if tile == 4:
                    vaccine = Vaccine (col_count * tile_size + (tile_size // 2), row_count * tile_size + (tile_size // 2))
                    vaccine_group.add(vaccine)
                if tile == 8:
                    exit = Exit(col_count * tile_size, row_count * tile_size - (tile_size // 2))
                    exit_group.add(exit)
                col_count += 1
            row_count += 1

    def draw(self):
        for tile in self.tile_list:
            screen.blit(tile[0], tile[1])
  



class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load('img/virus.png')
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.move_direction = 1
        self.move_counter = 0

    def update(self): #updates what's in the parameters (for the game)
        self.rect.x += self.move_direction
        self.move_counter += 1
        if abs(self.move_counter) > 50:
            self.move_direction *= -1
            self.move_counter *= -1

class Vaccine(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        img = pygame.image.load('img/vaccine.png')
        self.image = pygame.transform.scale(img,(29,45))
        self.rect = self.image.get_rect()
        self.rect.center = (x,y)
    
            
class Exit(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        img = pygame.image.load('img/exit.png')
        self.image = pygame.transform.scale(img, (tile_size, int(tile_size * 1.5)))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

world_data = [
[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], 
[1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1], 
[1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1], 
[1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 1], 
[1, 0, 3, 0, 0, 2, 2, 2, 0, 0, 0, 0, 2, 2, 0, 0, 0, 2, 2, 0, 0, 0, 2, 2, 2, 2, 1], 
[1, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1], 
[1, 2, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1], 
[1, 0, 0, 0, 0, 0, 2, 2, 2, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1], 
[1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 0, 0, 0, 2, 2, 2, 0, 0, 0, 1],
[1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
[1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 1],
[1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 1],
[1, 0, 0, 0, 0, 2, 2, 2, 0, 0, 3, 0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1],
[1, 0, 0, 0, 2, 1, 1, 1, 4, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
[1, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
]

player = Player(100, screen_height - 130)
virus_group = pygame.sprite.Group()
vaccine_group = pygame.sprite.Group()
exit_group = pygame.sprite.Group()

world = World(world_data)

state="title"
next=False
btnNew=button("btnPlay.png")
btnQuiz=button("btnQuiz.png")
btnResult=button("btnResult.png")
btnLesson=button("btnLesson.png")
btnBack= button("btnBack.png")
btnExit=button("btnExit.png")
btnMenu=button("btnMenu.png")
btnNext=button("btnNext.png")

error = bigfont.render(('Error!!!!!!!!!'), True, (200,0,10))

try:
  while keepGoing:
    clock.tick(60) #delay
    screen.fill((9,131,180)) 

    if state=="title":
        setBackground("title.png")
        bm=screen.blit(btnMenu,(350,270))#bm- menu button

    elif state=="menu":
       # buttons-------------------
        setBackground("menu.png")
        bp=screen.blit(btnNew,(100,320))   #bp- btnPLay
        bq=screen.blit(btnQuiz,(225,320))    #bq- btnQuiz
        br=screen.blit(btnResult,(350,320))     #br- btnResult
        bl=screen.blit(btnLesson,(475,320))    #bl- btnLesson
        be=screen.blit(btnExit,(600,320))    #be- btnExit

    elif state=="game":  

      if not next:
        setBackground("summary.png")
        bsg=screen.blit(btnNext,(350,380)) #btnstartgame

      if next: 
        screen.blit(bg_img, (0, 0))
        screen.blit(sun_img, (100, 100))

        world.draw()

        if game_over == 0:
          virus_group.update()

          if pygame.sprite.spritecollide(player, vaccine_group, True):
            score += 1
          draw_text("X " + str(score), font_score, white, tile_size - 10, 10)
      
        virus_group.draw(screen)
        vaccine_group.draw(screen)
        exit_group.draw(screen)

        game_over = player.update(game_over)
        
        #if play has died
        if game_over == -1:
              player.reset(100, screen_height - 130)
              game_over = 0   
              score = 0
              #increase viruses
              world = World(world_data)
        #if player has completed the level
        elif pygame.sprite.spritecollide(player, exit_group, False) and score==5:
              #reset game and go to next level
              state="menu"

    elif state=="quiz":
            # ---------------code for the quiz-------------------
      question=0
      correctAnswers=0

      setBackground("quiz.png")

      btnNext=button("btnNext.png")
      bnq=screen.blit(btnNext,(650,380))   #bnq- btnNext(questions)
      bb=screen.blit(btnBack,(50,380))   #bb- button btnBack


    elif state=="questions":
        correct=str("maybe")
        setBackground("q"+str(question)+".png")

        option1=quizOption("q"+str(question)+"o1.png")
        o1=screen.blit(option1,(35,200))

        option2=quizOption("q"+str(question)+"o2.png")
        o2=screen.blit(option2,(235,200))

        option3=quizOption("q"+str(question)+"o3.png")
        o3=screen.blit(option3,(435,200))


        option4=quizOption("q"+str(question)+"o4.png")
        o4=screen.blit(option4,(635,200))

    elif state=="message":
        if correct=="yes":
          setBackground("correct.png")
        elif correct=="no":
          setBackground("incorrect.png")
        bno=screen.blit(btnNext,(650,380)) 
        
    elif state=="result":
            # ---------------code for the quiz results-------------------
      percentage=round((correctAnswers/5)*100)
      setBackground(str(percentage)+".png")
      bbr=screen.blit(btnBack,(650,380))   #bbr- btn back (results)

    elif state=="lesson":
            # ---------------code for the lesson-------------------
      lessonNumber=0            
      setBackground("lesson.png")
      bnl=screen.blit(btnNext,(650,380)) #bnl - button next lesson
      bb=screen.blit(btnBack,(50,380))

    elif state=="lessons":
            
      if lessonNumber<5:
        setBackground("lesson"+str(lessonNumber)+".png")
        bnl=screen.blit(btnNext,(650,380)) #bnl - button next lesson
      elif lessonNumber==5:
        setBackground("lesson5.png")
        bb=screen.blit(btnBack,(50,380))

    elif state=="exit":
      time+=1
      if time <= 250:
        setBackground("Credits.png")
      elif time>250 and time<500:
        setBackground("Credits2.png")
      else:
        keepGoing= False

    else:
      screen.blit(error, (20,60))       # print text error

                
    pygame.display.flip()
    #Handle any events in the current frame
    for ev in pygame.event.get(): 
      if ev.type == pygame.QUIT: #<-- this special event type happens when the window is closed
        keepGoing = False
      elif ev.type == MOUSEBUTTONDOWN:
        pos=pygame.mouse.get_pos()

        if bm.collidepoint(pos):
          state="menu" 


        elif state=="menu":              
          if bp.collidepoint(pos):
            state="game"
          elif bq.collidepoint(pos):
            state="quiz"
          elif br.collidepoint(pos):
            state="result"   
          elif bl.collidepoint(pos):
            state="lesson"  
          elif be.collidepoint(pos):
            state="exit"


        elif state=="game":
          if bsg.collidepoint(pos):
            next=True


        elif state=="result":
          if bbr.collidepoint(pos):
            state="menu"  


        elif state=="quiz":
          if bnq.collidepoint(pos):
            state="questions"
            question+=1
          elif bb.collidepoint(pos):
            state="menu"  


        elif state=="questions":

          if question==1:
            if o4.collidepoint(pos):
              correct="yes"
              correctAnswers+=1
            elif o1.collidepoint(pos) or o2.collidepoint(pos) or o3.collidepoint(pos):
              correct="no"
            state="message"

          elif question==2:
            if o1.collidepoint(pos):
              correct="yes"
              correctAnswers+=1
            elif o2.collidepoint(pos) or o3.collidepoint(pos) or o4.collidepoint(pos):
              correct="no"
            state="message"
          
          elif question==3:
            if o1.collidepoint(pos):
              correct="yes"
              correctAnswers+=1
            elif o2.collidepoint(pos) or o3.collidepoint(pos) or o4.collidepoint(pos):
              correct="no"
            state="message"
          
          elif question==4:
            if o1.collidepoint(pos):
              correct="yes"
              correctAnswers+=1
            elif o2.collidepoint(pos) or o3.collidepoint(pos) or o4.collidepoint(pos):
              correct="no"
            state="message"

          elif question==5:
            if o3.collidepoint(pos):
              correct="yes"
              correctAnswers+=1
            elif o1.collidepoint(pos) or o2.collidepoint(pos) or o4.collidepoint(pos):
              correct="no"
            state="message"


        elif state=="message":
            if bno.collidepoint(pos):
              state="questions"
              question+=1
              if question>5:
                state="result"


        elif state=="lesson" or state=="lessons":
          if bnl.collidepoint(pos):
            state="lessons" 
            lessonNumber+=1    
          elif bb.collidepoint(pos):
            state="menu"  



finally:
  pygame.quit()  # Keep this IDLE friendly 